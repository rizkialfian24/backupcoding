<?php

return [
    'site_title' => 'simple siakad | sangcahaya.com',
];
